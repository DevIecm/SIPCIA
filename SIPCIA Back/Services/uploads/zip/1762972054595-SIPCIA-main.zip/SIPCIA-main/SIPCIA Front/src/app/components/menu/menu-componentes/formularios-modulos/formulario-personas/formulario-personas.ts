import { Component } from '@angular/core';

@Component({
  selector: 'app-formulario-personas',
  imports: [],
  templateUrl: './formulario-personas.html',
  styleUrl: './formulario-personas.css'
})
export class FormularioPersonas {

}
