export const environment = {
  production: false,
  //apiUrl: 'http://145.0.40.23:4002/api/' //DESAROLLO
  //apiUrl: 'https://app.iecm.mx/sipcia/api/' //PROD 
  apiUrl: 'http://145.0.46.49:4000/api/'
  //apiUrl: 'http://localhost:4000/api/'
};